
#include <stdio.h>

int main (void)
{
  
	FILE *pToF;

	//pToF = fopen ("data", "w");
	
	pToF = fopen ("data", "a");
	fprintf (pToF, "Programming is fun.\n");

	fclose (pToF);
  
 	return 0;
}
