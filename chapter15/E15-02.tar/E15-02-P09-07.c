// Counting words


#include <stdio.h>
#include <stdbool.h>


// Function to determine if a character is alphabetic

bool alphabetic (const char c)
{
	if ( (c >= 'a' && c <= 'z') || ( c >= 'A' && c <= 'Z') )
		return true;
	else
		return false;
}

// Function to count the number of words in a string

int countWords (const char string[])
{
	int i, wordCount = 0;
	bool lookingForWord = true, alphabetic (const char c);

	for ( i = 0; string[i] != '\0'; ++i )
		if ( alphabetic(string[i]) )
		{
			if ( lookingForWord )
			{
				++wordCount;
			lookingForWord = false;
			}
		}
		else
			lookingForWord = true;

	return wordCount;
}

int main (void)
{
	char buffer[80];
	FILE * pInputF, * pOutputF;
	int countWords (const char string[]);

	if ( (pInputF = fopen ("file1", "r")) == NULL )
	{
		fprintf (stderr, "Cannot open data for reading.\n");
		return 1;
	}


	fgets (buffer, 80, pInputF);
	
	fputs (buffer, stdout);
	
	fprintf (pOutputF,"%d\n", countWords (buffer));

	fclose (pInputF);
	fclose (pOutputF);


	return 0;
}

			

	

