#include <stdio.h>

int main (void)
{
  int sum;
  
  sum = 50 + 25;
  printf ("The sum of 50 and 25 is %i.\n", sum);
  
  return 0;
}

