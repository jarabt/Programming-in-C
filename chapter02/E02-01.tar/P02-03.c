#include <stdio.h>

int main (void)
{
  printf ("Testing...\n..1\n...2\n....3\n");
  
  return 0;
}
