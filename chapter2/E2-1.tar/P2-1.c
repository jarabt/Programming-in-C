#include <stdio.h>

int main (void)
{
	  printf ("Programming is fun.\n");
	    
	    return 0;
}
